/* O código tem como objetivo criar uma classe de Funcionario com nome, sobrenome e o valor do salario desse Funcionario, depois precisa imprimir o resultado e ainda complementar com os 10% do salario desse mesmo Funcionario */

#include <iostream>
#include<string> //biblioteca de string
#include <cstdlib>

using namespace std;

class Pessoa{
  private: //Devinindo as variaveis que vão ser privadas
    string nome;
    string sobrenome;
    double salario;
  public: //devinindo as funçoes publicas
    void setSobrenome(string novoSobrenome){ //setando o sobrenome
      sobrenome = novoSobrenome;
    }
    void setNome(string novoNome){//setando o nome
      nome = novoNome;
    }
    void setSalario(double novoSalario){//setando o salario
      salario = novoSalario;
    }
    double getSalario(){ //retornando o salario
      return salario;
    }
    string getNome(){ //retornando o nome
      return nome;
    }
    string getSobrenome(){ //retornando o sobrenome
      return sobrenome;
    };
    void imprime(){ //funçao pra imprimir o resultado
      cout <<"Nome: " << getNome()<< endl;
      cout <<"Sobrenome:  " << getSobrenome()<< endl;
      cout << "Salario anual: " << getSalario()*12 << endl;
    }
};
int main() {
  Pessoa p1; //devinindo p1 a chave de acesso para as funçoes
  p1.setNome("Sergio");
  p1.setSobrenome("Carlos");
  p1.setSalario(3000);
  
  Pessoa p2; //devinindo p2 a chave de acesso para as funçoes
  p2.setNome("Kaike");
  p2.setSobrenome("José");
  p2.setSalario(4000);
  cout << "Pessoa 1" << endl;
  p1.imprime(); // chamando a funçao que imprime
  cout << "==============================" << endl;
  cout << "Pessoa 2" << endl;
  p2.imprime(); // chamando a funçao que imprime
  cout << "==============================" << endl;
  
  //pegando os 10% do salario
  p1.setSalario(p1.getSalario()*1.1); 
  p2.setSalario(p2.getSalario()*1.1);
  //imprimindo como o valor novo do salario
  p1.imprime();
  p2.imprime();
  
}