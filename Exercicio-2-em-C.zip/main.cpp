/* Esse código é para definir alguma data, então precisamos criar uma classe com dia, mes e ano e imprimir com uma "/" entre os resultas */

#include <iostream>
#include<string>


using namespace std;

class Date{
  private: //Devinindo as variaveis privadas
    int mes;
    int dia;
    int ano;
  public: //Devinindo o que vai ser publico
    void setDia(int novoDia){ 
      //Precisa tirar os casos impossiveis
      if(novoDia < 1)
        dia = 1;
      else if(novoDia > 31)
        dia = 31;
      else
        dia = novoDia;
    }
    void setAno(int novoAno){
      ano = novoAno;
    }
    void setMes(int novoMes){
      //Precisa tirar os casos impossiveis
      if(novoMes < 1)
        mes = 1;
      else if(novoMes > 12)
        mes = 12;
      else
        mes = novoMes;
    }
    int getDia(){ //retorna o dia
      return dia;
    }
    int getMes(){ //retorna o mes
      return mes;
    }
    int getAno(){ //retorna o ano
      return ano;
    }
    void imprime(){ //void pra imprimir o resultado
      cout << getDia() << "/" << getMes() << "/" << getAno();
    }
};

int main() {
  Date d; //Devinindo que d será a "chave" pra acessar a classe Date
  d.setDia(20);
  d.setMes(02);
  d.setAno(1999);
  
  d.imprime();
  
  
}