/* O código tem como objetivo criar uma classe de Funcionario com nome, sobrenome e o valor do salario desse Funcionario, depois precisa imprimir o resultado e ainda complementar com os 10% do salario desse mesmo Funcionario */


class Funcionario { //devinindo a classe Funcionario 
    
    String nome;
    String sobrenome;
    double salario;
    //Devinindo as funçoes publicas
    public void setSobrenome(String novoSobrenome) { //setando o sobrenome
        sobrenome = novoSobrenome;
    }

    public void setSalario(double novoSalario) { //setando o salario
        if(novoSalario < 0)
            salario = 0;
        else
            salario = novoSalario;
    }

    public void setNome(String novoNome) { //setando o nome
        nome = novoNome;
    }
    
    public String getNome(){ //funçao pra retornar o nome
        return nome;
    }
    public String getSobrenome(){ //funçao pra retornar o sobrenome
        return sobrenome;
    }
    public double getSalario(){ //funçao pra retornar o salario
        return salario;
    }
    public void imprime(){ //funçao para imprimir o resultado
        System.out.println("Nome:   " + getNome());
        System.out.println("Sobrenome:  " + getSobrenome());
        System.out.println("Salario anual:    " + getSalario()*12);
    }
}

public class Aula1Java {
    public static void imprimeFunc(Funcionario z){
        System.out.println("Nome:   " + z.getNome());
        System.out.println("Sobrenome:  " + z.getSobrenome());
        System.out.println("Salario anual:    " + z.getSalario()*12);
    }
    public static void main(String[] args) {
        
        Funcionario f = new Funcionario(); //declarando f a variavel chave pro acesso a classe de Funcionario
        
        f.setNome("Sergio");
        f.setSobrenome("Carlos");
        f.setSalario(30000.25);
        
        Funcionario g = new Funcionario(); //declarando g a variavel chave pro acesso a classe de Funcionario
        
        g.setNome("Albert");
        g.setSobrenome("Mendes");
        g.setSalario(9999999);
        
        f.imprime();
        g.imprime();
        
        //dando os 10% do salario
        f.setSalario(f.getSalario()*1.1);
        g.setSalario(g.getSalario()*1.1);
        
        //imprimindo com o novo valor do salario
        f.imprime();
        g.imprime();
    }

}
