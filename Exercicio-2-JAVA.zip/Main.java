/* Esse código é para definir alguma data, então precisamos criar uma classe com dia, mes e ano e imprimir com uma "/" entre os resultas */
package exercicio.pkg2.aula.pkg2;

class Date { // devinindo a classe Date
    int mes;
    int dia;
    int ano;
    //devinindo as funçoes como publicas
    public void setMes(int novoMes) { //Funçao pra setar o mes
        if(mes < 1)
            mes = 1;
        else if (mes > 12)
            mes = 12;
        else
            mes = novoMes;
    }
    public void setDia(int novoDia) { //Funçao pra setar o dia
        if (dia < 1)
            dia = 1;
        else if (dia > 31)
            dia = 31;
        else
            dia = novoDia;
    }
    public void setAno(int novoAno){ //Funçao pra setar o ano
        ano = novoAno;
    }
    public int getMes(){ //retornando o mes
        return mes;
    }
    public int getDia(){ //retornando o dia
        return dia;
    }
    public int getAno(){ //retornando o ano
        return ano;
    }
    public void imprime(){ //funçao pra imprimir o resultado
        System.out.println(getNome() + "/" + getDia() + "/" +  getAno);
        
    }    
        
}
   

public class Exercicio2Aula2 {

    
    public static void main(String[] args) {
        Date d = new Date(); //devinindo d como a chave de acesso para as funçoes da Date
        
        d.setDia(12); 
        d.setMes(5);
        d.setAno(2018);
        
        d.imprime();
    }
    
}
